package elements;

public class BattleMonopoly {
	
}
