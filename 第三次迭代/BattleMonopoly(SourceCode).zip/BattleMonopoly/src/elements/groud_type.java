package elements;

public enum groud_type {
	ISASSET,ISTEMPLE,GENERAL;
}
