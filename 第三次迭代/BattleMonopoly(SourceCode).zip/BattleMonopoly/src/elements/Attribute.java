package elements;

public class Attribute {
	public Attribute() {
		
	}
}
