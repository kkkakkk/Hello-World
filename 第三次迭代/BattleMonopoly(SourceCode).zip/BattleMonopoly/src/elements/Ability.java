package elements;

public class Ability {
	public String name;
	
	public Ability(String s) {
		name=s;
	}
}
