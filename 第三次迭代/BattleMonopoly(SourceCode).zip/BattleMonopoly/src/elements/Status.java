package elements;

public class Status {
	public Status() {
		
	}
}
