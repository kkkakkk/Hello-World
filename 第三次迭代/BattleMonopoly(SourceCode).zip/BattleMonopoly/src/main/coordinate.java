package main;

public class coordinate {
	public int x;
	public int y;
	public int position;
	
	public coordinate() {
		x=0;
		y=0;
		position=0;
	}
	
	public void next() {
		position=(position+1)%36;
		switch (y) {
			case 0:
				if (x!=9) x++;
				else y++;
				break;
			case 9:
				if (x!=0) x--;
				else y--;
				break;
			default:
				if (x==0) y--;
				else y++;
		}
				
	}
}
