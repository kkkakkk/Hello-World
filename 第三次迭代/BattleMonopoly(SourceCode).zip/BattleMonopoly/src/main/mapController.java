package main;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import elements.*;
import main.coordinate;

public class mapController {
	@FXML
	private AnchorPane ap;
	@FXML
	private Button yaotouzi;
	@FXML
	private GridPane gp1;
	@FXML
	private Text one;
	@FXML
	private Text two;
	@FXML
	private Text three;
	@FXML
	private TextField tf1;
	@FXML
	private TextField tf2;
	@FXML
	private TextField tf3;
	@FXML
	private TextField tf4;
	@FXML
	private TextField tf5;
	@FXML
	private TextField tf6;
	@FXML
	private TextField tf7;
	@FXML
	private TextField tf8;
	@FXML
	private TextField tf9;
	@FXML
	private VBox vb1;
	
	private int turn=0;
	private coordinate co1=new coordinate();
	private coordinate co2=new coordinate();
	private coordinate co3=new coordinate();
	
	private void MoveText(GridPane g,Text t,coordinate c,int step) {
		for (int i=1;i<=step;++i) {
			c.next();
		}
		g.getChildren().remove(t);
		GridPane temp=(GridPane) g.getChildren().get(c.position);
		VBox temp2=(VBox) temp.getChildren().get(0);
		temp2.getChildren().add(t);
		}
	
	private void ShowRank(VBox v,int max,int middle,int min) {
		v.getChildren().clear();
		Text t1=new Text(max+"�����");
		Text t2=new Text(middle+"�����");
		Text t3=new Text(min+"�����");
		v.getChildren().addAll(t1,t2,t3);
	}

	public void GetPointAndUpdate() {
		int pointnumber=Die.getInstance().throwdie();
		tf2.setText(String.valueOf(pointnumber));
		tf1.setText(String.valueOf((turn%3)+1));
		tf3.setText(String.valueOf(((turn+1)%3)+1));
		turn+=1;
		
		switch (tf1.getText()) {
			case "1":
				MoveText(gp1,one,co1, pointnumber);
				System.out.println("1�����ǰ��"+pointnumber+"����");
				tf7.setText(String.valueOf((Integer.parseInt(tf7.getText())+pointnumber)));
				if (co1.position<pointnumber) {
					tf4.setText(String.valueOf((Integer.parseInt(tf4.getText())+1)));
					System.out.println("1���������ɵ�"+tf4.getText()+"Ȧ��");
				}
				break;
			case "2":
				MoveText(gp1,two,co2, pointnumber);
				System.out.println("2�����ǰ��"+pointnumber+"����");
				tf8.setText(String.valueOf((Integer.parseInt(tf8.getText())+pointnumber)));
				if (co2.position<pointnumber) {
					tf5.setText(String.valueOf((Integer.parseInt(tf5.getText())+1)));
					System.out.println("2���������ɵ�"+tf5.getText()+"Ȧ��");
				}
				break;
			case "3":
				MoveText(gp1,three,co3, pointnumber);
				System.out.println("3�����ǰ��"+pointnumber+"����");
				tf9.setText(String.valueOf((Integer.parseInt(tf9.getText())+pointnumber)));
				if (co3.position<pointnumber) {
					tf6.setText(String.valueOf((Integer.parseInt(tf6.getText())+1)));
					System.out.println("3���������ɵ�"+tf6.getText()+"Ȧ��");
				}
		}
		
		if (Integer.parseInt(tf7.getText())<Integer.parseInt(tf8.getText())) {
			if (Integer.parseInt(tf7.getText())<Integer.parseInt(tf9.getText())) {
				if (Integer.parseInt(tf8.getText())<Integer.parseInt(tf9.getText())) ShowRank(vb1,3,2,1);
				else ShowRank(vb1,2,3,1);
			}
			else ShowRank(vb1,2,1,3);
		}
		else {
			if (Integer.parseInt(tf7.getText())<Integer.parseInt(tf9.getText())) ShowRank(vb1,3,1,2);
			else {
				if (Integer.parseInt(tf8.getText())<Integer.parseInt(tf9.getText())) ShowRank(vb1,1,3,2);
				else ShowRank(vb1,1,2,3);
			}
		}
	}
}
